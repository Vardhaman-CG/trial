package com.capg.busticketbooking.service;


import com.capg.busticketbooking.entity.Trips;

import java.time.LocalDateTime;
import java.util.List;

public interface ITripsService {
    List<Trips> getAllTrips();

    List<Trips> getTripsByBusTypeAndDate(String type, LocalDateTime tripDate);
    public List<Trips> searchTrips(String fromCity, String toCity, LocalDateTime tripDate);

}
