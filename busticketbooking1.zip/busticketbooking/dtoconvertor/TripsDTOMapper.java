package com.capg.busticketbooking.dtoconvertor;

import com.capg.busticketbooking.dto.TripsDTO;
import com.capg.busticketbooking.entity.Trips;
import org.springframework.stereotype.Component;

@Component
public class TripsDTOMapper {

    public TripsDTO mapTripsToTripsDTO(Trips t) {
        if (t == null) {
            return null;
        }

        return TripsDTO.builder()
                .tripId(t.getTripId())
                .boardingAddressId(t.getBoardingAddress() != null ? t.getBoardingAddress().getAddressId() : null)
                .droppingAddressId(t.getDroppingAddress() != null ? t.getDroppingAddress().getAddressId() : null)
                .departureTime(t.getDepartureTime())
                .arrivalTime(t.getArrivalTime())
                .availableSeats(t.getAvailableSeats())
                .fare(t.getFare())
                .tripDate(t.getTripDate())
                .busId(t.getBus() != null ? t.getBus().getBusId() : null)
                .routeId(t.getRoute() != null ? t.getRoute().getRouteId() : null)
                .driver1Id(t.getDriver1() != null ? (Integer) t.getDriver1().getDriverId() : null)
                .driver2Id(t.getDriver2() != null ? (Integer) t.getDriver2().getDriverId() : null)
                .build();
    }
}