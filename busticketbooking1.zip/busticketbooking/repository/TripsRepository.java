package com.capg.busticketbooking.repository;

import com.capg.busticketbooking.entity.Trips;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface TripsRepository extends JpaRepository<Trips, Integer> {

    // Derived query: uses field names
    List<Trips> findByBus_TypeAndTripDate(String type, LocalDateTime tripDate);

    // Custom query for fromCity, toCity, and tripDate
    @Query("SELECT t FROM Trips t " +
            "WHERE t.route.fromCity = :fromCity " +
            "AND t.route.toCity = :toCity " +
            "AND t.tripDate = :tripDate")
    List<Trips> searchTrips(@Param("fromCity") String fromCity,
                            @Param("toCity") String toCity,
                            @Param("tripDate") LocalDateTime tripDate);
}