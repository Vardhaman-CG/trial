package com.capg.busticketbooking.repository;

import com.capg.busticketbooking.entity.Routes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoutesRepository extends JpaRepository<Routes, Integer> {
}