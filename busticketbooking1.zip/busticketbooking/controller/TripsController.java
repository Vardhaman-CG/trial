package com.capg.busticketbooking.controller;
import com.capg.busticketbooking.dto.TripsDTO;
import com.capg.busticketbooking.dtoconvertor.TripsDTOMapper;
import com.capg.busticketbooking.entity.Trips;
import com.capg.busticketbooking.service.ITripsService;
import com.capg.busticketbooking.service.TripsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/busticketbooking/trips")
public class TripsController {

    @Autowired
    private ITripsService tripsService;

    @Autowired
    private TripsDTOMapper mapper;

    @GetMapping("/bus_type/{type}/trip_date/{trip_date}")
    public List<Trips> getTripsByBusTypeAndDate(
            @PathVariable("type") String type,
            @PathVariable("trip_date") String tripDate) {

        LocalDate date = LocalDate.parse(tripDate);
        LocalDateTime tripDateTime = date.atStartOfDay();

        return tripsService.getTripsByBusTypeAndDate(type, tripDateTime);
    }

    @GetMapping("/{fromCity}/{toCity}/{tripDate}")
    public ResponseEntity<List<TripsDTO>> searchTrips(@PathVariable String fromCity,
                                                      @PathVariable String toCity,
                                                      @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss") LocalDateTime tripDate) {
        List<Trips> trips = tripsService.searchTrips(fromCity, toCity, tripDate);
        if (trips != null && !trips.isEmpty()) {
            List<TripsDTO> dtoresp = new ArrayList<>();
            for (Trips t : trips) {
                TripsDTO dto = mapper.mapTripsToTripsDTO(t);
                dtoresp.add(dto);
            }
            return ResponseEntity.ok(dtoresp);
        }
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/getall")
    public ResponseEntity<List<Trips>> getAllTrips() {
        return ResponseEntity.ok(tripsService.getAllTrips());
    }

}