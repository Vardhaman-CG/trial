package com.capg.busticketbooking.mapper;

// Placeholder generic mapper if needed in future. Currently not used but kept for extensibility.
public class GenericMapper {
}

