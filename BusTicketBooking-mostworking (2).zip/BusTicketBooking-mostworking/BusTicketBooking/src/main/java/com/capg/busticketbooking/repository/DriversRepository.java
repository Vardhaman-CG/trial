package com.capg.busticketbooking.repository;

import com.capg.busticketbooking.entity.Drivers;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DriversRepository extends JpaRepository<Drivers, Integer> {
}