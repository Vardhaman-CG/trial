package com.capg.busticketbooking.entity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusTicketBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
