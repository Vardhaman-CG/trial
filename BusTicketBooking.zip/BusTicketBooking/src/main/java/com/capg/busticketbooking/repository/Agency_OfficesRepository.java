package com.capg.busticketbooking.repository;

import com.capg.busticketbooking.entity.Agency_Offices;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Agency_OfficesRepository extends JpaRepository<Agency_Offices, Integer> {
}